---
layout: home
---

Watch the show [on YouTube](https://www.youtube.com/@BrentFarris)

If you're a developer of any kind, web developer, game developer, systems developer, etc; this is the podcast for you. This show goes into latest news, topics, tips, and tricks in tech and programming. The show won't shy away from technical topics in programming, mathematics, artificial intelligence, and game design. Come join the podcast you might even wind up learning something new!
